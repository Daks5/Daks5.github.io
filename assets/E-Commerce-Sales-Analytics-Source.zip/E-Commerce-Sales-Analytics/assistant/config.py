from dataclasses import dataclass, field
import os
from pathlib import Path
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Settings:
    host: str
    port: int
    database: str
    user: str
    password: str = field(repr=False)
    api_key: str = field(repr=False, default='')
    model: str = 'gemini-3.5-flash-lite'
    max_requests: int = 30
    embedding_model: str = 'gemini-embedding-001'

    @classmethod
    def load(cls):
        values = dotenv_values(ROOT / '.env')
        def get(name, default=''):
            return os.getenv(name, values.get(name) or default)
        return cls(
            host=get('MYSQL_HOST', '127.0.0.1'), port=int(get('MYSQL_PORT', '3306')),
            database=get('MYSQL_DATABASE', 'ecommerce_db'),
            user=get('MYSQL_ASSISTANT_USER') or get('MYSQL_USER'),
            password=get('MYSQL_ASSISTANT_PASSWORD') if get('MYSQL_ASSISTANT_USER') else get('MYSQL_PASSWORD'),
            api_key=get('GEMINI_API_KEY'), model=get('GEMINI_MODEL', 'gemini-3.5-flash-lite'),
            max_requests=max(1, min(int(get('ASSISTANT_MAX_REQUESTS', '30')), 100)),
            embedding_model=get('GEMINI_EMBEDDING_MODEL', 'gemini-embedding-001'),
        )

    @property
    def gemini_ready(self):
        return bool(self.api_key.strip()) and not self.api_key.startswith(('your_', 'replace_'))
