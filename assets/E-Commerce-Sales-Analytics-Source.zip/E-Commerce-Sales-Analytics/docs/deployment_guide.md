# Deploying the resume demonstration

The local project combines Python cleaning, MySQL analysis, Power BI reporting,
and a separate Streamlit assistant using Gemini and document RAG. Online hosting
is a separate delivery step. No cloud account, paid service, public repository,
or database exposure has been created by these final checks.

## Recommended route: Streamlit Community Cloud and hosted MySQL

1. Prepare a curated GitHub repository with `assistant/`, `sql/`, the four
   knowledge documents, `.streamlit/config.toml`, requirements, and the README.
   Exclude `.env`, passwords, API keys, virtual environments, installers, and
   private diagnostics. Include dashboard screenshots and Power BI definitions
   as portfolio evidence. Hosting Streamlit does not publish Power BI.
2. Export and restore the project schema/data/views to hosted MySQL 8, or run
   the pipeline against an empty cloud project database. Create a separate
   SELECT-only assistant account. A cloud app cannot use your laptop's
   `127.0.0.1` database.
3. Configure and verify encrypted MySQL access using the host's CA and TLS
   requirements. Current code has no explicit remote TLS configuration.
4. Put a recognized `requirements.txt` beside `assistant/app.py`, using
   `requirements-assistant.txt` as the tested reference. The current root
   `requirements.txt` belongs to the pipeline; `requirements-assistant.txt`
   is not selected automatically by Community Cloud. Use Python 3.13 to match
   the local environment.
5. Use the platform's secret manager. Settings already accept environment
   variables. Community Cloud exposes root-level TOML secrets as environment
   variables. Configure `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_DATABASE`,
   `MYSQL_ASSISTANT_USER`, `MYSQL_ASSISTANT_PASSWORD`, `GEMINI_API_KEY`,
   `GEMINI_MODEL`, and `GEMINI_EMBEDDING_MODEL`. Never upload the local `.env`.
6. Supply `data/knowledge/index.json` through a controlled artifact or explicit
   build step. It is currently Git-ignored. Keep its four source documents
   identical to the indexed versions. The app refuses an absent/stale index
   and never rebuilds silently.
7. Override the local server binding to `0.0.0.0` and use the hosting platform's
   required port. Current configuration binds to `127.0.0.1` for local use.
8. Use controlled viewer access or add an application-wide request budget
   before sharing Gemini access publicly. The 30-request browser allowance
   resets with new sessions and is not a global spending limit. This resume
   demo does not need product features, but shared API usage needs protection.
9. Select the GitHub repository, branch, and `assistant/app.py` in Community
   Cloud, configure secrets/Python, and deploy. Check SQL figures, citations,
   unsupported questions, quota errors, and a cold restart on the online URL.

Use a hosted database rather than forwarding a public port to laptop MySQL.
Database hosting and Gemini usage depend on the selected plans; this guide
does not assume a free database tier or quote an unverified price.

## Official documentation

- [Streamlit deployment](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy)
- [Dependency files](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies)
- [Cloud secrets](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/secrets-management)
- [Viewer authentication](https://docs.streamlit.io/develop/concepts/connections/authentication)

Final local verification is in `reports/final_project_test_results.xml` and
`reports/final_project_audit.json`. Prior Power BI native checks are separate
delivery evidence; a file-integrity check is not a fresh Desktop refresh.
Passing local tests does not certify a cloud deployment.
