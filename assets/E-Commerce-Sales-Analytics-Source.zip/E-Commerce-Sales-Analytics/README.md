# E-Commerce Sales & Operations Analytics

A resume project turning a public e-commerce export into a reproducible Python → MySQL → SQL → Power BI analysis. The business question is: **which products and regions drive shipped sales, what explains the comparable-period decline, and where do cancellation and data-quality issues deserve investigation?**

The completed **Commerce Pulse** dashboard uses a dark analytical theme, synchronized filters, an aligned May/June comparison and decision-focused product, market and operations pages. Open `powerbi/CommercePulse.pbix` for the saved report or `powerbi/CommercePulse.pbip` for its editable project. See [redesign details](docs/dashboard_redesign.md).

## Version 2: separate AI analyst

`assistant/` adds a Gemini-powered Streamlit interface using the same MySQL model and metric definitions. Double-click **Start AI Analyst.cmd**, then open http://127.0.0.1:8501. Chat requires `GEMINI_API_KEY` in the existing local `.env`; the Query Explorer can run all 14 reviewed SQL analyses without Gemini. Answers expose aggregate tables, charts, filters and SQL evidence. Gemini 3.5 Flash Lite passed nine curated live routing cases; see [setup, architecture and limitations](docs/ai_assistant.md) and `reports/assistant_completion.json` for verification status. The Power BI files remain the Version 1 dashboard.

## Dataset and results

The AI analyst now also retrieves cited project documentation for definitions, cleaning decisions and dataset scope. SQL continues to calculate the figures. Its knowledge index is built locally from four approved documents using Gemini embeddings. See [document RAG workflow and rebuild instructions](docs/rag_guide.md).

[Kaggle source: Unlock Profits with E-Commerce Sales Data](https://www.kaggle.com/datasets/thedevastator/unlock-profits-with-e-commerce-sales-data). Seven CSVs contain 178,405 source rows. All are preserved and loaded into separate SQL staging tables. The Amazon report supplies the main 128,975-row fact; six duplicate copies are flagged, producing 128,969 analytical lines across 120,378 orders.

- ₹6.97 crore valued shipped sales; 107,746 units; ₹695.03 complete-order AOV.
- Comparable June 1–29 value is 6.72% below May 1–29; Set contributes 68.08% of the net decline.
- Merchant cancelled-line rate is 17.47%, versus Amazon's 12.79%; this is a descriptive association.
- 7,792 retained missing amounts and 115 unvalued shipped lines are exposed, not filled with zero.

Read [business findings](docs/business_findings.md), [metric definitions](docs/metric_contract.md), and [cleaning decisions](docs/cleaning_decisions.md). Profit, collected revenue, retention and causal uplift are outside the available evidence.

## Architecture

```mermaid
flowchart LR
 A[Kaggle ZIP · 7 CSVs] --> B[Python profile and clean]
 A --> C[MySQL raw staging]
 B --> D[MySQL star model]
 C --> D
 D --> E[14 SQL business analyses]
 D --> F[Verified SQL CSV exports]
 F --> G[Commerce Pulse · 4 pages · 45 measures]
 E --> H[Findings and reproducible plots]
```

```mermaid
erDiagram
 dim_date ||--o{ fact_order_lines : date_key
 dim_product ||--o{ fact_order_lines : product_key
 dim_geography ||--o{ fact_order_lines : geography_key
 dim_status ||--o{ fact_order_lines : status_key
```

## Run locally

Use Python 3.13, MySQL 8, and Power BI Desktop. See [software setup](SETUP.md).

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# Enter your local project-account credentials in .env; never commit it.
.\.venv\Scripts\python.exe src\download_dataset.py
.\.venv\Scripts\python.exe src\profile_data.py
.\.venv\Scripts\python.exe src\clean_data.py
.\.venv\Scripts\python.exe src\load_mysql.py
.\.venv\Scripts\python.exe src\analyze.py
.\.venv\Scripts\python.exe src\build_powerbi.py
.\.venv\Scripts\python.exe src\build_dark_powerbi.py
.\.venv\Scripts\python.exe src\prepare_dark_validation.py
```

Create an empty `ecommerce_db` database and a database-scoped loader account first. This machine's account is already configured locally. The loader refuses unmanaged nonempty databases and changed source fingerprints. Existing complete project tables are reused; failed partial loads require review rather than deletion.

Open `notebooks/01_sales_analysis.ipynb` for the executed analytical walkthrough. On this machine, open `powerbi/CommercePulse.pbix` for the saved dashboard. For the editable project, open `powerbi/CommercePulse.pbip`, adjust `ProjectRoot` if relocating, and refresh. [Power BI usage](docs/powerbi_guide.md). SQL DDL, views, CTEs, ranking, lag and running-total queries are in `sql/`.

## Verification and delivery status

The Python/MySQL checks pass for source and fact row counts, individual line IDs/order IDs/amounts, money and units, category/state/fulfillment/B2B totals, and join cardinality. Evidence: `reports/validation.json`. All seven SQL source counts match the inventory.

**Phase one and the dashboard redesign are complete.** The final report is saved in `powerbi/CommercePulse.pbix`. All 45 DAX measures compiled without errors; 141 checks reconcile totals, category changes, positive/negative chart series and the 29 aligned daily values with SQL (`reports/powerbi_dark_engine_validation.json`). All four pages were inspected in Desktop on 6 October 2026. Category, reporting-month, fulfillment and customer-type slicers were exercised and cleared; category synchronization across pages and the fixed comparison's Date-filter behavior were confirmed. Generated definitions passed Microsoft schemas before Desktop save; Desktop advanced some saved schema versions whose public schema is unavailable, so the final saved definitions were verified in Desktop. Delivery evidence is recorded in `reports/dashboard_redesign_completion.json`. The earlier SalesAnalytics report and its 71 checks remain recorded in `reports/phase_one_completion.json`.

## Dashboard screenshots

These are captures of the actual refreshed Power BI report. The `.pbix` is available locally and excluded from Git; these screenshots and the editable `.pbip` definitions are repository artifacts.

| Sales pulse | Product drivers |
| --- | --- |
| ![Sales pulse](reports/screenshots_dark/01_sales_pulse.png) | ![Product drivers](reports/screenshots_dark/02_product_drivers.png) |
| Market demand | Operations |
| ![Market demand](reports/screenshots_dark/03_market_demand.png) | ![Operations](reports/screenshots_dark/04_operations.png) |

Raw data, generated CSV exports, credentials, local caches and installers are excluded from Git. The downloader rebuilds the source data. This repository is prepared locally; it has not been published to GitHub.

## Resume wording

“Built an LLM and RAG e-commerce analytics assistant combining 14 reviewed SQL tools with semantic retrieval over four project documents, displaying database evidence and traceable source citations.”

“Extended the project with a Gemini-powered Streamlit analyst that routes natural-language questions to 14 validated SQL tools, supports contextual filters, and displays query evidence; verified 70 automated checks and nine curated live LLM cases.”

“Built a reproducible Python–MySQL–Power BI sales analytics pipeline for 178K source rows, modeling 129K Amazon order lines in a validated star schema with 14 SQL analyses, 45 DAX measures and a four-page interactive dashboard.”

“Identified a 6.72% comparable-period shipped-value decline and traced 68.08% of its net change to the Set category; quantified fulfillment cancellation gaps while documenting missing values, duplicate assumptions and partial-month limitations.”

Do not claim a measured business improvement from this public-data exercise.
