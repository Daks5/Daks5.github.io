# Project software setup

This project uses its own Python 3.13 environment in `.venv`.

## Installed components

- Project Python: 3.13.3.
- Microsoft Jupyter extension for VS Code: 2025.9.1, with its required companion extensions.
- Oracle MySQL Connector/NET: 26.7.0; the 64-bit .NET Framework provider is registered and loads successfully.
- Pandas, NumPy, Matplotlib, Seaborn, SQLAlchemy, PyMySQL with authentication support, IPykernel, and JupyterLab are installed in `.venv`. Exact versions are recorded in `requirements.txt`.

Verification passed for dependency consistency, dataframe aggregation, chart rendering, and execution through the project notebook kernel. Python's MySQL driver loads successfully. The installation checks do not require a database password.

If Power BI was open during installation, close and reopen it to detect Connector/NET. The connector installer did not request a PC restart.

## Use the environment in VS Code

1. Open this project folder in VS Code.
2. Run **Python: Select Interpreter** from the Command Palette and choose `.venv\Scripts\python.exe`.
3. For notebooks, use **Select Kernel → Python Environments** and choose the same `.venv`.

The workspace settings point to this environment. If VS Code was already open while the Jupyter extension was installed, reload its window.

You can run Python without changing PowerShell's execution policy or activating the environment:

```powershell
.\.venv\Scripts\python.exe your_script.py
```

To launch JupyterLab when needed:

```powershell
.\.venv\Scripts\python.exe -m jupyterlab
```

## Recreate the environment

`requirements.in` lists the direct dependencies. `requirements.txt` records the installed package versions, including their dependencies.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The SQL stack uses SQLAlchemy and PyMySQL with authentication support. MySQL Connector/NET is a separate Windows component used by Power BI.

The local `ecommerce_loader` account connects successfully to MySQL 8.0.46 and has access to the `ecommerce_db` project database. All seven raw sources and the star model are loaded and reconciled. Its password is stored only in the ignored local `.env`; the repository includes a placeholder `.env.example`.

Power BI Desktop 2.158.1177.0 is installed. The completed dark dashboard is saved at `powerbi/CommercePulse.pbix`, with editable definitions at `powerbi/CommercePulse.pbip`. All 45 DAX measures pass 141 reconciliation checks. Visual inspection and screenshot status is tracked in the README and `reports/dashboard_redesign_completion.json`.
